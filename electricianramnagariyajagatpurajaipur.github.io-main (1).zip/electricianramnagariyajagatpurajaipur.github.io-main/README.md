import zipfile

import os



# Create a folder for the website

folder_name = "/mnt/data/electrician_website"

os.makedirs(folder_name, exist_ok=True)



# Website HTML code

html_code = """<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Electrician Services - Ramnagariya, Jagatpura</title>

  <style>

    body {

      font-family: Arial, sans-serif;

      margin: 0;

      padding: 0;

      background: #f5f5f5;

      color: #333;

    }

    header {

      background: #0073e6;

      color: white;

      padding: 20px;

      text-align: center;

    }

    header h1 {

      margin: 0;

    }

    section {

      padding: 20px;

      max-width: 800px;

      margin: auto;

    }

    .contact {

      background: white;

      padding: 20px;

      border-radius: 10px;

      box-shadow: 0 0 10px rgba(0,0,0,0.1);

      margin-top: 20px;

    }

    .contact p {

      font-size: 18px;

      margin: 10px 0;

    }

    .btn {

      display: inline-block;

      background: #0073e6;

      color: white;

      padding: 10px 20px;

      border-radius: 5px;

      text-decoration: none;

      margin-top: 10px;

    }

    footer {

      text-align: center;

      padding: 15px;

      background: #222;

      color: white;

      margin-top: 20px;

    }

  </style>

</head>

<body>

  <header>

    <h1>Electrician Services</h1>

    <p>Ramnagariya, Jagatpura - Jaipur</p>

  </header>



  <section>

    <h2>Welcome!</h2>

    <p>

      We provide reliable and affordable electrician services in 

      <b>Ramnagariya, Jagatpura, Jaipur</b>. From wiring to repairs, we ensure 

      safety and quality service for homes and businesses.

    </p>



    <div class="contact">

      <h2>Contact Details</h2>

      <p><b>Mobile:</b> <a href="tel:+919887980556">+91 9887980556</a></p>

      <p><b>WhatsApp:</b> <a href="https://wa.me/919887980556" target="_blank">Chat on WhatsApp</a></p>

      <p><b>Address:</b><br>

        A24 Shivam Nagar, Kesh Vihar, Ramnagariya, Jagatpura,<br>

        Jaipur, Rajasthan 302017

      </p>

      <a class="btn" href="tel:+919887980556">Call Now</a>

      <a class="btn" href="https://wa.me/919887980556" target="_blank">WhatsApp</a>

    </div>

  </section>



  <footer>

    <p>© 2025 Electrician Services | Jaipur</p>

  </footer>

</body>

</html>

"""



# Save index.html

html_path = os.path.join(folder_name, "index.html")

with open(html_path, "w", encoding="utf-8") as f:

    f.write(html_code)



# Create a ZIP file

zip_path = "/mnt/data/electrician_website.zip"

with zipfile.ZipFile(zip_path, "w") as zipf:

    zipf.write(html_path, "index.html")



zip_path
